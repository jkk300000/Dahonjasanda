import React, { useEffect, useState } from "react";
import { useTheme } from "@mui/material/styles";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import { Divider } from "@mui/material";
import Link from "next/link";

import Container from "components/Container";
import bankimage from "../../../../src/images/banks/wr_bank.png";
import cardimage from "../../../../src/images/cards/wr_card.jpg";

// Import the Axios service functions at the top of your component file
import { findDepositList } from "../../DepositsApiService";


const VerticalMinimalDesignedBlogCards = ({ category }) => {
  const theme = useTheme();
  const [products, setProducts] = useState([]);

  useEffect(() => {
    if (!category) {
      console.error('Category is undefined, cannot fetch data.');
      return;
    }
  
    const fetchData = async () => {
      try {
        const response = await findDepositList(`/${category}`);
        console.log(response.data); // 이 부분을 추가
        setProducts(response.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
  
    fetchData();
  }, [category]); // 빈 배열을 넘겨주어 컴포넌트 마운트 시에만 실행되도록 함

  // Log the image paths
  // console.log(
  //   "Image paths:",
  //   savingsPlanData.map((plan) => plan.image)
  // );

  return (
    <Container>
      <Grid container spacing={4}>
        {products.map((product, index) => (
          <Grid item xs={12} key={index}>
            {/* <Link href={`/deposit/${index}`} passHref> */}
            <Card
              sx={{
                width: 1,
                height: 1,
                boxShadow: 4,
                display: "flex",
                flexDirection: "row", // Change to row
                transition: "all .2s ease-in-out",
                "&:hover": {
                  transform: `translateY(-${theme.spacing(1 / 2)})`,
                },
                height: 200,
              }}
            >
              <Box
                sx={{
                  width: "20%", // 이미지와 같은 너비 설정
                  display: "inline-block", // 인라인 블록으로 설정하여 텍스트와 올바르게 정렬
                  padding: product.image.src.endsWith(".png") ? "38px" : "0px", // 조건부 패딩 적용
                  boxSizing: "border-box", // 패딩을 포함한 총 너비 유지
                }}
              >
                <CardMedia
                  component="img"
                  image={product.imageUrl || '../../images/banks/wr_bank.png'}
                  alt={`${product.finPrdtNm} image`}
                  sx={{
                    width: "100%", // 감싸는 컨테이너에 맞게 너비 조정
                    height: "100%", // 필요한 경우 높이 조정
                    objectFit: "contain",
                    objectPosition: "center",
                  }}
                />
              </Box>
              <CardContent
                sx={{
                  width: "80%", // 전체 카드 대비 내용 영역의 너비 설정
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                {/* ProductName을 상단에 배치 */}
                <Typography
                  variant="h5"
                  gutterBottom
                  component="div"
                  sx={{ marginBottom: "1px" }}
                >
                  {product.finPrdtNm}
                </Typography>
                {/* 상품 이름과 상세 정보를 구분하는 선 */}
                <Divider sx={{ marginBottom: "16px" }} />

                <Grid container spacing={2} alignItems="flex-start">
                  {/* 각 항목에 대한 라벨 */}
                  <Grid item xs={3} sx={{ paddingRight: "24px" }}>
                    {" "}
                    {/* 여기에 오른쪽 패딩 추가 */}
                    <Typography color="text.secondary">가입 기간</Typography>
                    <Typography color="text.secondary">가입 한도</Typography>
                    <Typography color="text.secondary">이자율</Typography>
                    <Typography color="text.secondary">
                      계좌 개설 채널
                    </Typography>
                    <Typography color="text.secondary">특별 조건</Typography>
                  </Grid>

                  {/* 라벨과 데이터 사이의 수직 구분선 대신 패딩 또는 테두리 사용 */}

                  {/* 데이터 값 */}
                  <Grid
                    item
                    xs={8}
                    sx={{
                      borderLeft: 2, // 테두리 두께 설정
                      borderColor: "divider", // 테두리 색상 설정, 'divider'는 테마에서 정의된 기본 구분선 색상
                      paddingLeft: "24px", // 내용과 테두리 사이에 간격 추가
                    }}
                  >
                    <Typography color="text.primary">
                      {product.saveTrm}
                    </Typography>
                    <Typography color="text.primary">
                      {product.saveTrm}
                    </Typography>
                    <Typography color="text.primary">
                      {product.intrRate2}
                    </Typography>
                    <Typography color="text.primary">
                      {product.mtrtInt}
                    </Typography>
                    <Typography color="text.primary">
                      {product.spclCnd}
                    </Typography>
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
            {/* </Link> */}
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default VerticalMinimalDesignedBlogCards;
