export const sectionsData = [
    {
      title: "예금",
      groups: [
        {
          name: "은행별",
          options: [
            { name: "국민은행", value: "KB" },
            { name: "신한은행", value: "SH" },
            { name: "우리은행", value: "WR" },
          ],
        },
        {
          name: "단복리",
          options: [
            { name: "단리", value: "simple" },
            { name: "복리", value: "compound" },
          ],
        },
        {
          name: "월납입금액",
          options: [
            { name: "단리", value: "simple" },
            { name: "복리", value: "compound" },
          ],
        },
        {
          name: "기간",
          options: [
            { name: "1년", value: "1" },
            { name: "2년", value: "2" },
            { name: "3년", value: "3" },
            { name: "5년", value: "5" },
            { name: "10년", value: "10" },
            { name: "21년", value: "21" },
            { name: "22년", value: "22" },
            { name: "23년", value: "23" },
            { name: "25년", value: "25" },
            { name: "210년", value: "210" },
            // Add other options here
          ],
        },
        // Add other groups here
      ],
    },
    // Add other sections here for "Saving", etc.
    {
      title: "적금",
      groups: [
        {
          name: "은행별",
          options: [
            { name: "국민은행", value: "KB" },
            { name: "신한은행", value: "SH" },
            { name: "우리은행", value: "WR" },
          ],
        },
        {
          name: "단복리",
          options: [
            { name: "단리", value: "simple" },
            { name: "복리", value: "compound" },
          ],
        },
        {
          name: "기간",
          options: [
            { name: "1년", value: "1" },
            { name: "2년", value: "2" },
            { name: "3년", value: "3" },
            { name: "5년", value: "5" },
            { name: "10년", value: "10" },
            // Add other options here
          ],
        },
        // Add other groups here
      ],
    },
    // Add other sections here for "Annuity ", etc.
    {
      title: "연금",
      groups: [
        {
          name: "은행별",
          options: [
            { name: "국민은행", value: "KB" },
            { name: "신한은행", value: "SH" },
            { name: "우리은행", value: "WR" },
          ],
        },
        {
          name: "납입기간",
          options: [
            { name: "1년", value: "1" },
            { name: "2년", value: "2" },
            { name: "3년", value: "3" },
            { name: "5년", value: "5" },
            { name: "10년", value: "10" },
          ],
        },
        {
          name: "가입나이",
          options: [
            { name: "20대", value: "20" },
            { name: "30대", value: "30" },
            { name: "40대", value: "40" },
            { name: "50대", value: "50" },
            { name: "60대", value: "60" },
          ],
        },
        {
          name: "수령조건",
          options: [
            { name: "생존", value: "alive" },
            { name: "사망", value: "dead" },
            // Add other options here
          ],
        },
        // Add other groups here
      ],
    }
  ];
