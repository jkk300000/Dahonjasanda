import { useRouter } from 'next/router';

const SavingsProductDetails = () => {
  const router = useRouter();
  const { planId } = router.query;

  // Use planId to fetch data or for other logic

  return (
    <div>
      {/* Display details here */}
      <p>Showing details for plan ID: {productId}</p>
    </div>
  );
};

export default SavingsProductDetails;