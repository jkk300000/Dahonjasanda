export { default } from './animalMain';
