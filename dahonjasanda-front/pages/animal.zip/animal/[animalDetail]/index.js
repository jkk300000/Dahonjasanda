export { default } from './animalDetailMain';
