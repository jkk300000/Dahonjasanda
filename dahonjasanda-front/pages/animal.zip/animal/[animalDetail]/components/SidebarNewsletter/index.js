export { default } from './SidebarNewsletter';
