export { default } from './CaseStudies';
