export { default } from './FeaturedArticle';
