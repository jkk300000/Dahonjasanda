export { default as Hero } from './Hero';
export { default as SearchBox } from './SearchBox';
export { default as LastStories } from './LastStories';
export { default as CaseStudies } from './CaseStudies';
export { default as PopularArticles } from './PopularArticles';
export { default as FeaturedArticle } from './FeaturedArticle';
export { default as Newsletter } from './Newsletter';
